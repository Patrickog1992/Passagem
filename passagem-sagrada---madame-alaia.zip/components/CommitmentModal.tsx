import React, { useState, useEffect } from 'react';

interface CommitmentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ZODIAC_SIGNS = [
  "Áries", "Touro", "Gêmeos", "Câncer", "Leão", "Virgem",
  "Libra", "Escorpião", "Sagitário", "Capricórnio", "Aquário", "Peixes"
];

export const CommitmentModal: React.FC<CommitmentModalProps> = ({ isOpen, onClose }) => {
  const [timeLeft, setTimeLeft] = useState(120); // 2 minutes in seconds
  const [step, setStep] = useState<'form' | 'processing'>('form');
  
  // Form States
  const [yourName, setYourName] = useState('');
  const [hisName, setHisName] = useState('');
  const [hisSign, setHisSign] = useState('');
  const [yourSign, setYourSign] = useState('');
  
  // Checkboxes
  const [check1, setCheck1] = useState(false);
  const [check2, setCheck2] = useState(false);
  const [check3, setCheck3] = useState(false);

  // Removido useEffect de scroll lock pois agora é uma página

  useEffect(() => {
    if (timeLeft === 0) setTimeLeft(120);
    
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      clearInterval(interval);
    };
  }, [isOpen]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const handleContinue = () => {
    setStep('processing');
    
    setTimeout(() => {
      // Redirecionamento para o checkout após a animação de conexão
      window.location.href = "https://go.perfectpay.com.br/PPU38CQ63ME";
    }, 3000);
  };
  
  if (!isOpen) return null;

  return (
    <div className="min-h-screen w-full bg-[#0f0c1a] flex flex-col font-poppins text-gray-200 relative">
      
      {/* Header ESTATICO (Rola com a página, fica no topo do fluxo) */}
      <div className="w-full bg-[#0f0c1a] border-b border-purple-500/30 shadow-2xl py-4">
        <div className="max-w-3xl mx-auto px-4 relative flex items-center justify-center min-h-[60px]">
          
          {/* Botão X na esquerda do container central */}
          <button 
            onClick={onClose} 
            className="absolute left-4 text-purple-300 hover:text-white transition-colors p-2 rounded-full hover:bg-white/10"
            aria-label="Voltar"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          {/* Texto Centralizado */}
          {step === 'form' && (
            <div className="text-center pt-2">
              <h3 className="text-white font-bold text-lg leading-tight">Passo 1: Concorde com a Passagem Sagrada</h3>
              <p className="text-red-500 font-bold font-mono text-sm animate-pulse mt-1">
                Isso vai expirar em... {formatTime(timeLeft)}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Conteúdo com padding normal (sem pt-32) pois o header não é mais fixed */}
      <div className="p-4 md:p-8 flex-1 w-full max-w-3xl mx-auto flex flex-col">
        {step === 'form' ? (
          <div className="space-y-6 pb-10">
            
            <div className="space-y-4 bg-purple-900/20 p-6 rounded-xl border border-purple-500/20 shadow-inner">
              <h4 className="text-purple-300 font-bold mb-2 uppercase tracking-wide text-sm">Termos de Compromisso</h4>
              
              <label className="flex items-start gap-4 cursor-pointer group p-2 hover:bg-purple-900/10 rounded-lg transition-colors">
                <div className="relative flex items-center mt-1">
                  <input 
                    type="checkbox" 
                    checked={check1}
                    onChange={(e) => setCheck1(e.target.checked)}
                    className="peer h-6 w-6 cursor-pointer appearance-none rounded border-2 border-purple-400 bg-gray-900 checked:bg-purple-500 checked:border-purple-500 transition-all"
                  />
                  <svg className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 pointer-events-none opacity-0 peer-checked:opacity-100 text-white" viewBox="0 0 14 14" fill="none">
                    <path d="M3 8L6 11L11 3.5" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <span className={`text-base md:text-lg leading-tight text-white group-hover:text-gray-200 transition-colors`}>
                  Eu entendo que a crença é necessária para que este feitiço funcione
                </span>
              </label>

              <label className="flex items-start gap-4 cursor-pointer group p-2 hover:bg-purple-900/10 rounded-lg transition-colors">
                <div className="relative flex items-center mt-1">
                  <input 
                    type="checkbox" 
                    checked={check2}
                    onChange={(e) => setCheck2(e.target.checked)}
                    className="peer h-6 w-6 cursor-pointer appearance-none rounded border-2 border-purple-400 bg-gray-900 checked:bg-purple-500 checked:border-purple-500 transition-all"
                  />
                  <svg className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 pointer-events-none opacity-0 peer-checked:opacity-100 text-white" viewBox="0 0 14 14" fill="none">
                    <path d="M3 8L6 11L11 3.5" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <span className={`text-base md:text-lg leading-tight text-white group-hover:text-gray-200 transition-colors`}>
                  Eu não tornarei ninguém mais ciente deste feitiço (isso causará o desencantamento)
                </span>
              </label>

              <label className="flex items-start gap-4 cursor-pointer group p-2 hover:bg-purple-900/10 rounded-lg transition-colors">
                <div className="relative flex items-center mt-1">
                  <input 
                    type="checkbox" 
                    checked={check3}
                    onChange={(e) => setCheck3(e.target.checked)}
                    className="peer h-6 w-6 cursor-pointer appearance-none rounded border-2 border-purple-400 bg-gray-900 checked:bg-purple-500 checked:border-purple-500 transition-all"
                  />
                  <svg className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 pointer-events-none opacity-0 peer-checked:opacity-100 text-white" viewBox="0 0 14 14" fill="none">
                    <path d="M3 8L6 11L11 3.5" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <span className={`text-base md:text-lg leading-tight text-white group-hover:text-gray-200 transition-colors`}>
                  Eu entendo que, uma vez que este feitiço seja lançado, não há como voltar atrás
                </span>
              </label>
            </div>

            <div className="space-y-6 bg-[#161223] p-6 rounded-xl border border-gray-800 shadow-lg">
              <div>
                <label className="block text-base font-bold text-purple-300 mb-2">Seu nome completo</label>
                <input 
                  type="text" 
                  value={yourName}
                  onChange={(e) => setYourName(e.target.value)}
                  placeholder="Digite seu nome..."
                  className="w-full bg-gray-900 border border-purple-500/50 rounded-lg p-4 text-white text-lg placeholder-gray-600 focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 transition-all shadow-inner"
                />
              </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-base font-bold text-purple-300 mb-2">Seu Signo</label>
                    <select 
                      value={yourSign}
                      onChange={(e) => setYourSign(e.target.value)}
                      className="w-full bg-gray-900 border border-purple-500/50 rounded-lg p-4 text-white text-lg focus:outline-none focus:border-purple-400 shadow-inner"
                    >
                      <option value="">Selecionar...</option>
                      {ZODIAC_SIGNS.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-base font-bold text-purple-300 mb-2">Signo Dele</label>
                    <select 
                      value={hisSign}
                      onChange={(e) => setHisSign(e.target.value)}
                      className="w-full bg-gray-900 border border-purple-500/50 rounded-lg p-4 text-white text-lg focus:outline-none focus:border-purple-400 shadow-inner"
                    >
                      <option value="">Selecionar...</option>
                      {ZODIAC_SIGNS.map(s => <option key={s} value={s}>{s}</option>)}
                      <option value="unknown">Não sei (Usar Nome)</option>
                    </select>
                  </div>
              </div>
              {hisSign === 'unknown' && (
                  <p className="text-sm text-green-400 text-center italic border border-green-900/30 bg-green-900/10 p-2 rounded">
                    ✨ Madame Alaia usará a conexão energética do nome dele para encontrá-lo.
                  </p>
              )}

              <div>
                <label className="block text-base font-bold text-purple-300 mb-2">O nome dele</label>
                <input 
                  type="text" 
                  value={hisName}
                  onChange={(e) => setHisName(e.target.value)}
                  placeholder="Digite o nome dele..."
                  className="w-full bg-gray-900 border border-purple-500/50 rounded-lg p-4 text-white text-lg placeholder-gray-600 focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 transition-all shadow-inner"
                />
              </div>
            </div>

            <div className="pt-4">
              <button 
                onClick={handleContinue}
                className="w-full py-5 rounded-xl font-bold text-xl uppercase tracking-wider transition-all shadow-lg transform active:scale-95 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 text-white shadow-green-900/50 animate-pulse-slow ring-2 ring-green-400 ring-offset-2 ring-offset-[#0f0c1a]"
              >
                Confirmar Passagem
              </button>
            </div>

          </div>
        ) : (
          <div className="flex flex-col items-center justify-center space-y-8 text-center h-full min-h-[50vh] flex-1">
            <div className="relative">
              <div className="w-24 h-24 border-4 border-purple-500/30 rounded-full"></div>
              <div className="w-24 h-24 border-4 border-purple-500 border-t-transparent rounded-full animate-spin absolute top-0 left-0"></div>
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-2xl">
                🔮
              </div>
            </div>
            <div className="space-y-4 max-w-md">
              <h3 className="text-2xl font-bold text-white">Conectando Almas...</h3>
              <p className="text-gray-400 text-lg">Madame Alaia está analisando a compatibilidade astral e preparando a Passagem Sagrada...</p>
              <div className="w-full bg-gray-800 rounded-full h-2 mt-6 overflow-hidden">
                <div className="bg-purple-500 h-2 rounded-full animate-[width_3s_ease-in-out_infinite]" style={{width: '60%'}}></div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};